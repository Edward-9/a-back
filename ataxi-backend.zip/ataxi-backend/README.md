# ataxi-backend

## App
- build and start:  
 ```make up```
- stop and remove volumes:  
 ```make down```
 
- base URL: http://localhost:1000/
