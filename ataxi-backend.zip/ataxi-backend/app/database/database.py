import asyncpg
import pandas as pd

from ..utils import logger
from ..settings import DATABASE, DB_CONNECTION_POOL


class Database:
    def __init__(
        self,
        user,
        password,
        host,
        port,
        database,
        min_size=1,
        max_size=10,
        command_timeout=60,
    ):

        self.user = user
        self.password = password
        self.host = host
        self.port = port
        self.database = database
        self.min_size = min_size
        self.max_size = max_size
        self.command_timeout = command_timeout
        self._cursor = None

        self._connection_pool = None

    async def connect(self):
        if not self._connection_pool:
            try:
                self._connection_pool = await asyncpg.create_pool(
                    host=self.host,
                    port=self.port,
                    user=self.user,
                    password=self.password,
                    database=self.database,
                    min_size=self.min_size,
                    max_size=self.max_size,
                    command_timeout=self.command_timeout,
                )
                logger.info("connect() Database pool connectionn opened")
            except Exception as e:
                logger.error(f"connect() Error {e}")

    async def fetch_query(self, query: str, res_type="rows", *args):
        assert res_type in ["rows", "row", "value", "df"]
        if not self._connection_pool:
            await self.connect()
        con = await self._connection_pool.acquire()
        try:
            res = None
            if res_type == "rows":  # return the results as a list of Record
                res = await con.fetch(query, *args)
            elif res_type == "row":  # return the first row
                res = await con.fetchrow(query, *args)
            elif res_type == "value":  # return a value in the first row
                res = await con.fetchval(query, *args)
            elif res_type == "df":  # return pandas.DataFrame
                q = await con.prepare(query)
                columns = [a.name for a in q.get_attributes()]
                data = await q.fetch()
                res = pd.DataFrame(data, columns=columns)
            return res
        except Exception as e:
            logger.error(f"fetch_query() Error {e}")
        finally:
            await self._connection_pool.release(con)

    async def close(self):
        if not self._connection_pool:
            try:
                await self._connection_pool.close()
                logger.info("close() Database pool connection closed")
            except Exception as e:
                logger.error(f"close() Error {e}")


global db

async def set_db_instance():
    global db
    db_instance = Database(**DATABASE, **DB_CONNECTION_POOL)
    await db_instance.connect()
    logger.info(f"set_db_instance()")
    db = db_instance
    return db_instance

async def get_db():
    global db
    if not db:
        db = await set_db_instance()
    return db


async def close_db_conn():
    global db
    try:
        await db.close()
        logger.info(f"close_db_conn()")
    except Exception as e:
        logger.error(f"close_db_conn() Error: {e}")
