from ..services import ApiMailing
from ..settings import URL_WEB

am = ApiMailing()


# Send email after creating order
def task_send_email_order(id_calc, email_to):

    subject = "А-Такси: Заказ оформлен"
    url = f"{URL_WEB}/transfer/order/{id_calc}"
    html = """
    <h3> Заказ оформлен </h3>
    <p> Добрый день! </p>
    <p> Заказ трансфера успешно оформлен и ожидает оплаты.<br>
        Заказ доступен по <a href="{url}" target="_blank"> ссылке </a> (<a href="{url}" target="_blank"> {url} </a>).
    </p>
    """

    ApiMailing().send_email(
        email_to=email_to, subject=subject, html=html.format(url=url)
    )

    return True


def task_send_email_carrier(body, email_to, subj):

    subject = subj
    url = f"{URL_WEB}/transfer/order/{id_calc}"
    html = """
    <h3> Заказ оформлен </h3>
    <p> Добрый день! </p>
    <p> Заказ трансфера успешно оформлен и оплачен.<br>

    </p>
    """

    ApiMailing().send_email(
        email_to=email_to, subject=subject, html=html
    )

    return True
