from ..services import set_bank_request_attrs


# Update bank request attributes
async def task_update_bank_request_attrs():
    await set_bank_request_attrs()
