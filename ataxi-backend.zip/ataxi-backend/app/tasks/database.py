from ..database import set_db_instance, close_db_conn


# Create pool of connections
async def task_open_db_conn():
    db = await set_db_instance()
    return db


# Close connection
async def task_close_db_conn():
    await close_db_conn()
