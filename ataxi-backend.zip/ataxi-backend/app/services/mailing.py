import os
import mimetypes
import smtplib
from email.mime.base import MIMEBase
from email.mime.audio import MIMEAudio
from email.mime.image import MIMEImage
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formatdate

from ..utils import logger
from ..settings import EMAIL


# Api 'mailing'
class ApiMailing:
    def __init__(self):

        # Email settings
        self.dict_settings = EMAIL
        self.server = self.dict_settings.get("server")
        self.server_auth = self.dict_settings.get("auth")
        self.is_tls = self.dict_settings.get("is_tls", False)
        self.email_from = self.dict_settings.get("email_default")
        self.timeout = self.dict_settings.get("timeout")

        # Logging
        self.is_logging = True

    # Send SMTP message
    def send_smtp_msg(self, email_from, email_to, msg):

        server = smtplib.SMTP(timeout=self.timeout)
        server._host = self.server.get("host")

        logger.info(f"send_email() host: {server._host}")

        try:
            server.connect(**self.server)
            if self.is_tls:
                server.starttls()
            server.login(**self.server_auth)
            server.sendmail(
                from_addr=email_from, to_addrs=email_to, msg=msg.as_string()
            )
            server.quit()
            is_error = False
            if self.is_logging:
                logger.info(f"send_email(): {email_from}, {email_to}")

        except Exception as e:
            is_error = True
            logger.error(f"send_email() Error: {e}")

        return is_error

    # Send email
    def send_email(self, email_to=None, email_from=None, subject=None, html=None):

        if email_from is None:
            email_from = self.email_from

        # Config email
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = email_from
        msg["To"] = email_to
        msg["Date"] = formatdate(localtime=True)

        # Html body
        msg.attach(MIMEText(html, "html"))

        # Send message
        is_error = self.send_smtp_msg(email_from=email_from, email_to=email_to, msg=msg)

        return is_error

    # Send email with files
    def send_email_files(
        self,
        email_to=None,
        email_from=None,
        subject=None,
        html=None,
        list_path_files=None,
    ):

        if list_path_files is None:
            list_path_files = []

        if email_from is None:
            email_from = self.email_from

        # Config email
        msg = MIMEMultipart("mixed")
        msg["Subject"] = subject
        msg["From"] = email_from
        msg["To"] = email_to
        msg["Date"] = formatdate(localtime=True)

        # Massages
        msg_alternative = MIMEMultipart("alternative")
        msg_related = MIMEMultipart("related")

        # Html body
        msg_related.attach(MIMEText(html, "html"))

        msg_alternative.attach(msg_related)
        msg.attach(msg_alternative)

        # Files
        try:
            content_type, encoding = mimetypes.guess_type(list_path_files[0])
        except:
            content_type, encoding = None, None
        if (content_type is None) or (encoding is not None):
            content_type = "application/octet-stream"
        main_type, sub_type = content_type.split("/", 1)

        for path_file in list_path_files:
            try:
                if main_type == "text":
                    fp = open(path_file, "r")
                    m = MIMEText(fp.read(), _subtype=sub_type)
                    fp.close()
                elif main_type == "image":
                    fp = open(path_file, "rb")
                    m = MIMEImage(fp.read(), _subtype=sub_type)
                    fp.close()
                elif main_type == "audio":
                    fp = open(path_file, "rb")
                    m = MIMEAudio(fp.read(), _subtype=sub_type)
                    fp.close()
                else:
                    fp = open(path_file, "rb")
                    m = MIMEBase(main_type, sub_type)
                    m.set_payload(fp.read())
                    fp.close()
                filename = os.path.basename(path_file)
                m.add_header("Content-Disposition", "attachment", filename=filename)
                msg.attach(m)
            except:
                continue

        # Send message
        is_error = self.send_smtp_msg(email_from=email_from, email_to=email_to, msg=msg)

        return is_error
