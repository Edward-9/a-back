from ..utils import fetch_db_query
from ..utils import logger


global url
global token


# Get bank request attributes
async def get_bank_request_attrs():
    res = await fetch_db_query(
        func="f_heads", schema="mytosb", res_json=True, is_logging=False
    )
    url = res.get("Url")
    token = res.get("Authorization")
    return url, token


# Set url, token
async def set_bank_request_attrs():
    global url
    global token
    url, token = await get_bank_request_attrs()
    logger.info("set_bank_request_attrs()")


# Get dict of request attributes
async def get_bank_request_dict_args(data):
    global url
    global token
    if (not token) or (not url):
        await set_bank_request_attrs()
    return {
        "url": url,
        "headers": {
            "Authorization": f"Bearer {token}",
        },
        "json": data,
    }