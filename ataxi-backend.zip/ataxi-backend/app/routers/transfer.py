
from fastapi import BackgroundTasks, Body
from fastapi_cache.decorator import cache

from ..routers import router
from ..crud import get_tariffs_matrix, calculate_transfer, create_order, get_order_id
from ..tasks import task_send_email_order
from ..utils import fetch_db_query, handle_response
from ..settings import CACHE_TTL


@handle_response("/tariffs")
@router.get("/tariffs")
#@cache(expire=CACHE_TTL)
async def get_tariffs():
    res = await get_tariffs_matrix()
    return res


@handle_response("/locations")
@router.get("/locations")
#@cache(expire=CACHE_TTL)
async def get_locations():
    res = await fetch_db_query(func="f_locat1", schema="ataxi_transfer", res_json=True)
    return res


@handle_response("/calculate")
@router.post("/calculate")
async def post_calculate(data=Body()):
    res = await calculate_transfer(data=data)
    return res


@handle_response("/order")
@router.post("/order")
async def post_order(background_tasks: BackgroundTasks, data=Body()):
    dict_res = await create_order(data=data)
    res = dict_res["res"]
    background_tasks.add_task(task_send_email_order, res["id_calc"], dict_res["email_to"])
    return res


@handle_response("/order_id")
@router.get("/order/{id}")
async def get_order(id: str):
    res = await get_order_id(id_calc=id)
    return res


@handle_response("/mail")
@router.post("/mail")
async def post_mail(data=Body()):
    dict_mail = await prepare_mail(data=data)
    res = dict_mail["carrier"]
    background_tasks.add_task(task_send_email_carrier, res["id_calc"], dict_res["email_to"])

    return res

