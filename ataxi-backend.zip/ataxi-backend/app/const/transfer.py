from ..settings import APP_LOGIN


TRANSFER_TYPES = {
    "group": 1,
    "individual": 2,
}

TRANSFER_TYPES_REVERSED = {v: k for k, v in TRANSFER_TYPES.items()}


ORDER_PARAMS_MAPPING = {
    "login": {
        "field": "login",
        "default": APP_LOGIN,
    },
    "transfer_type": {
        "field": "view_transfer",
    },
    "vehicle_size": {
        "field": "count_places",
        "datatype": "int",
    },
    "locations_0$from": {
        "datatype": "int",
    },
    "locations_0$to": {
        "datatype": "int",
    },
    "locations_1$from": {
        "datatype": "int",
    },
    "locations_1$to": {
        "datatype": "int",
    },
    "amount": {
        "field": "amount",
        "datatype": "int",
    },
    "timestamp": {
        "field": "timestamp",
    },
    "name": {
        "field": "name_customer",
    },
    "phone": {
        "field": "phone_customer",
    },
    "email": {
        "field": "email_customer",
    },
    "passengers_adult": {
        "field": "quote$$adult",
        "datatype": "int",
    },
    "passengers_children": {
        "field": "quote$$younger",
        "datatype": "int",
    },
    "passengers_kids": {
        "field": "quote$$baby",
        "datatype": "int",
    },
    "datetime_0$date": {},
    "datetime_0$time": {},
    "datetime_0$flight_train": {},
    "datetime_0$hotel": {},
    "datetime_1$date": {},
    "datetime_1$time": {},
    "datetime_1$flight_train": {},
    "datetime_1$hotel": {},
    "id_order": {
        "field": "id_order",
        "datatype": "int",
    },
    "id_calc": {
        "field": "id_calc",
    },
    "is_payed": {
        "field": "enable",
        "datatype": "bool",
    },
    "gid": {
        "field": "id_guest",
    },
}


ORDER_PARAMS_MAPPING_REVERSED = {}
for k, d in ORDER_PARAMS_MAPPING.items():
    key = d.get("field")
    mapping = d.copy()
    mapping["field"] = k
    ORDER_PARAMS_MAPPING_REVERSED[key] = mapping
