import gc

from fastapi import FastAPI
from fastapi.middleware import Middleware
from fastapi_utils.tasks import repeat_every
from starlette.middleware.cors import CORSMiddleware

from .routers import transfer
from .cache import init_cache
from .tasks import task_open_db_conn, task_close_db_conn, task_update_bank_request_attrs
from .utils import logger
from .settings import TOKEN_TTL


# App
middleware = [
    Middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
]
app = FastAPI(title="ataxi", middleware=middleware, docs_url="/docs", redoc_url=None)


# Router
app.include_router(transfer.router, prefix="/api/transfer")


# Redis
@app.on_event("startup")
def startup():
    init_cache()


# Database connect
@app.on_event("startup")
async def startup_event():
    await task_open_db_conn()
    logger.info("Server Startup")


# Tasks
@app.on_event("startup")
@repeat_every(seconds=TOKEN_TTL)
async def update_spb():
    await task_update_bank_request_attrs()


# gc
@app.on_event("startup")
@repeat_every(seconds=(1 * 60))
def task_gc() -> None:
    gc.collect()


# Database disconnect
@app.on_event("shutdown")
async def shutdown_event():
    await task_close_db_conn()
    logger.info("Server Shutdown")
