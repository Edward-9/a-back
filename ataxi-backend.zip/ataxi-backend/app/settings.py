import os

from fastapi import Request, Response
from sqlalchemy.orm import Session


# Server
APP_LOGIN = os.environ.get("APP_LOGIN", "web_ataxi")
URL_WEB = os.environ.get("URL_WEB", "http://localhost:8080")
URL_SBP = os.environ.get("URL_SBP", "https://courier.atotx.ru")
TOKEN_TTL = int(os.environ.get("TOKEN_TTL", 1 * 60 * 60))  # in seconds


# Database
DATABASE = {
    "host": os.environ.get("DB_HOST", "localhost"),
    "port": os.environ.get("DB_PORT", "5432"),
    "user": os.environ.get("DB_USER", "user"),
    "password": os.environ.get("DB_PASSWORD", "password"),
    "database": os.environ.get("DB_NAME", "db"),
}
DB_DRIVER = (os.environ.get("DB_DRIVER", "postgresql"),)
DB_CONNECTION_POOL = {
    "min_size": int(os.environ.get("DB_CONN_POOL_MIN", 1)),
    "max_size": int(os.environ.get("DB_CONN_POOL_MAX", 10)),
    "command_timeout": int(os.environ.get("DB_CONN_POOL_TIMEOUT", 60)),
}


# Redis
CACHE_TTL = int(os.environ.get("REDIS_CACHE_TTL", 3600))  # in seconds

REDIS_CACHE = {
    "host_url": os.environ.get("REDIS_URL", "redis://redis:6379"),
    "prefix": "app-cache",
}


# Email
EMAIL = {
    "server": {
        "host": os.environ.get("EMAIL_SERVER_HOST"),
        "port": os.environ.get("EMAIL_SERVER_PORT"),
    },
    "auth": {
        "user": os.environ.get("EMAIL_DEFAULT"),
        "password": os.environ.get("EMAIL_DEFAULT_PASSWORD"),
    },
    "is_tls": bool(int(os.environ.get("EMAIL_TLS", default=0))),
    "email_default": os.environ.get("EMAIL_DEFAULT"),
    "timeout": int(os.environ.get("EMAIL_TIMEOUT", default=60)),
}


# Date formats
DATE_FORMAT = "%Y-%m-%dT%H:%M"
DATE_FORMAT_DEFAULT = "%Y-%m-%d %H:%M:%S"


# Logger
PATH_LOGS = os.path.join(".", "logs", "app")
if not os.path.exists(PATH_LOGS):
    os.makedirs(PATH_LOGS)

LOGGER = {
    "path_file": os.path.join(PATH_LOGS, "main.log"),
    "log_max_size_mb": 10,
    "log_backup_count": 100,
}
