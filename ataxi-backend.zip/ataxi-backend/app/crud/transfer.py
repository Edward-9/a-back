import json
import pandas as pd
import uuid

from ..crud import up_order_bank
from ..utils import fetch_db_query, cast_datatype, map_fields
from ..utils import logger
from ..const import (
    TRANSFER_TYPES,
    TRANSFER_TYPES_REVERSED,
    ORDER_PARAMS_MAPPING,
    ORDER_PARAMS_MAPPING_REVERSED,
)


# Tariffs
async def get_tariffs_matrix() -> dict:

    # table
    q = """SELECT town, fld_sort, id_vehicle_size, vehicle_size, transfer_type, amount 
            FROM ataxi_transfer.mv_tariffs"""

    tariffs_table = await fetch_db_query(q=q, res_type="df", res_default=pd.DataFrame())

    tariffs_table[["amount"]] = tariffs_table[["amount"]].astype(int)

    # matrix
    tariffs_matrix = (
        tariffs_table.pivot(
            index=["town", "fld_sort"], columns=["id_vehicle_size"], values="amount"
        )
        .reset_index()
        .sort_values(by=["fld_sort"])
        .to_dict("records")
    )

    # fields
    df_fields = tariffs_table[
        ["id_vehicle_size", "vehicle_size", "transfer_type"]
    ].drop_duplicates()
    df_fields[["id_vehicle_size"]] = df_fields[["id_vehicle_size"]].astype(str)
    tariffs_fields = df_fields[["id_vehicle_size", "vehicle_size"]].rename(
        columns={"id_vehicle_size": "key", "vehicle_size": "label"}
    )
    tariffs_fields["class"] = "text-center"
    tariffs_fields = tariffs_fields.to_dict("records")
    tariffs_fields.insert(0, {"key": "town", "label": "Населенный пункт"})

    # fields_top
    tariffs_fields_top = (
        df_fields.groupby(["transfer_type"])
        .size()
        .reset_index(name="counts")
        .rename(columns={"transfer_type": "label"})
        .to_dict("records")
    )

    # vehicle_size
    vehicle_size = (
        df_fields[["id_vehicle_size", "vehicle_size"]]
        .rename(columns={"id_vehicle_size": "value", "vehicle_size": "text"})
        .to_dict("records")[2:]
    )

    # result
    res = {
        "items": tariffs_matrix,
        "fields": tariffs_fields,
        "fields_top": tariffs_fields_top,
        "vehicle_size": vehicle_size,
    }

    logger.info(f"get_tariffs_matrix() res: {res}")

    return res


# Get transfer
def get_dict_transfer(data: dict, idx: int = 0, type_op: str = None) -> dict:

    dict_transfer = {
        "from": cast_datatype(value=data.get(f"locations_{idx}$from"), datatype="int"),
        "to": cast_datatype(value=data.get(f"locations_{idx}$to"), datatype="int"),
    }

    if type_op == "order":
        dict_transfer["datetime"] = "{date}T{time}".format(
            date=data.get(f"datetime_{idx}$date"), time=data.get(f"datetime_{idx}$time")
        )
        dict_transfer["flight_train"] = data.get(f"datetime_{idx}$flight_train")
        dict_transfer["hotel"] = data.get(f"datetime_{idx}$hotel")

    return dict_transfer


# Parse transfer
def parse_transfer(params_transfer: dict) -> dict:

    dict_transfer = {}

    for idx, d in enumerate(params_transfer):
        for x in ["from", "to"]:
            dict_transfer[f"locations_{idx}${x}"] = d.get(x)
        for x in ["flight_train", "hotel"]:
            dict_transfer[f"datetime_{idx}${x}"] = d.get(x)
        date, time = d.get("datetime", "").split("T")
        dict_transfer[f"datetime_{idx}$date"] = date
        dict_transfer[f"datetime_{idx}$time"] = time

    return dict_transfer


# Calculate
async def calculate_transfer(data: dict) -> dict:

    # transfer
    transfer = [get_dict_transfer(data=data, idx=0, type_op="calculate")]

    if data.get("is_return"):
        transfer.append(get_dict_transfer(data=data, idx=1, type_op="calculate"))

    # calculate
    id_calc = str(uuid.uuid4())
    fields = [
        "login",
        "count_places",
        "transfer",
        "view_transfer",
        "timestamp",
        "id_guest",
    ]
    params = map_fields(data=data, mapping=ORDER_PARAMS_MAPPING_REVERSED, fields=fields)
    params["transfer"] = transfer
    params["view_transfer"] = TRANSFER_TYPES.get(data.get("transfer_type"))
    params["id_calc"] = id_calc

    amount = await fetch_db_query(
        func="f_calc",
        schema="ataxi_transfer",
        q_params=json.dumps(params),
        res_default=None,
    )

    res = {
        "id_calc": id_calc,
        "amount": amount,
    }

    logger.info(f"calculate_transfer() res: {res}")

    return res


# Order
async def create_order(data: dict) -> dict:

    STEP0 = "-------new payment:-------"
    logger.info(STEP0)

    # transfer
    transfer = [get_dict_transfer(data=data, idx=0, type_op="order")]

    if data.get("is_return"):
        transfer.append(get_dict_transfer(data=data, idx=1, type_op="order"))

    # order
    id_calc = data.get("id_calc")
    fields = [
        "login",
        "amount",
        "view_transfer",
        "count_places",
        "quote$$adult",
        "quote$$younger",
        "quote$$baby",
        "name_customer",
        "email_customer",
        "phone_customer",
        "transfer",
        "timestamp",
    ]
    params = map_fields(data=data, mapping=ORDER_PARAMS_MAPPING_REVERSED, fields=fields)
    params["transfer"] = transfer
    params["view_transfer"] = TRANSFER_TYPES.get(data.get("transfer_type"))
    params["id_calc"] = id_calc

    STEP1 = "query from client to bd:"
    logger.info(STEP1)
    logger.info(params)

    answer = await fetch_db_query(
        func="f_order1",
        schema="ataxi_transfer",
        q_params=params,
        res_json=True,
    )

    STEP2 = "answer from bd:"
    logger.info(STEP2)
    logger.info(answer)

    if answer.get("err") == 0:
        ansbank = await up_order_bank(xjson=answer)
        STEP5 = "qr_base64 and link to client:"
        logger.info(STEP5)
        logger.info(f"({type(ansbank)}) {ansbank}")
    else:
        if "err" in answer:
            del answer["err"]
        ansbank = answer

    if not ansbank or (type(ansbank) is not dict):
        ansbank = {}

    # Result
    dict_res = {
        "res": {
            "id_calc": id_calc,
            "id_order": ansbank.get("client", {}).get("id_order"),
        },
        "email_to": params.get("email_customer"),
    }
    logger.info(f"create_order() dict_res: {dict_res}")

    return dict_res


# Order (id)
async def get_order_id(id_calc: str):

    res = await fetch_db_query(
        func="f_order_id",
        schema="ataxi_transfer",
        q_params=id_calc,
        res_json=True
    )

    if not res:
        # exit
        return res

    params = res.pop("params", {})

    fields = list(ORDER_PARAMS_MAPPING.keys())
    data = {
        **map_fields(data=params, mapping=ORDER_PARAMS_MAPPING, fields=fields),
        **parse_transfer(params_transfer=params.get("transfer", {})),
        **res,
    }
    data["transfer_type"] = TRANSFER_TYPES_REVERSED.get(data.get("transfer_type"))

    logger.info(f"get_order_id() data: {data}")

    return data
