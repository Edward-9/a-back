import json

from ..services import get_bank_request_dict_args, set_bank_request_attrs
from ..utils import fetch_db_query, request_data
from ..utils import logger


# Get bank request attributes
async def get_bank_request_attrs():
    res = await fetch_db_query(
        func="f_heads", schema="mytosb", res_json=True, is_logging=False
    )

    url = res.get("Url")
    token = res.get("Authorization")

    return url, token


#  Send request to bank
async def _send_request_bank(data):

    # Request attributes
    dict_args = await get_bank_request_dict_args(data=data)

    # Request
    res = request_data(dict_args=dict_args, type_op="POST")

    return res, dict_args


# Send order to bank
async def up_order_bank(xjson):

    # Request data
    data = xjson.get("ans")

    if not data:
        # exit
        return

    datareq = data

    # Request
    res, dict_args = await _send_request_bank(data=datareq)

    STEP3 = "payquery to bank:"
    logger.info(STEP3)
    logger.info(dict_args["url"])
    logger.info(datareq)

    if not res:
        # update bank request attrs
        await set_bank_request_attrs()
        # try again
        res, dict_args = await _send_request_bank(data=datareq)

    STEP4 = "answer from bank qr_base64 and link:"
    logger.info(STEP4)
    logger.info(res)

    # Save bank answer to database
    newid = xjson.get("newid")
    ansbank = await fetch_db_query(
        func="f_ansbank",
        schema="mytosb",
        q_params=f"'{json.dumps(res)}',{newid}",
        q_s="",
        res_json=True,
    )

    return ansbank
