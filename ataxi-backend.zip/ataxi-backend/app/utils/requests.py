import json
import requests

from fastapi.responses import Response

from ..utils import logger


# Handle FastAPI response
def handle_response(route):
    def decorator(func):
        def wrapper(*args, **kwargs):
            func()
            try:
                func(*args, **kwargs)
            except Exception as e:
                logger.error(f"handle_response() Error: {route}. {e}")
                return Response(content=str(e), status_code=500)

        return wrapper

    return decorator


# GET / POST request
def request_data(dict_args, type_op="GET", get_single=False, is_logging=True):

    res = []
    if get_single:
        res = {}
    url = dict_args.get("url")

    logger.info(f"request_data() Request: {dict_args}")

    # Request
    try:
        if type_op == "POST":
            response = requests.post(**dict_args)
        else:
            response = requests.get(**dict_args)
    except Exception as e:
        logger.error(f"request_data() Error: {url}, {e}")
        return res

    # Response
    try:
        response_text = json.loads(response.text)
        if is_logging:
            logger.info(f"request_data() Response: {url}, {response_text}")
        if get_single and (type(response_text) is list) and (len(response_text) > 0):
            return response_text[0]
        return response_text
    except Exception as e:
        logger.error(
            f"request_data() response.text Error: {url}, {response}, {e}, request={dict_args}"
        )

    return res
