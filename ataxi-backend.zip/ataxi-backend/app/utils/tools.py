from app.utils import logger


# Cast datatype to value
def cast_datatype(value, datatype, raise_errors=False):
    if value is None:
        return value
    if (type(value) is str) and (datatype == "bool"):
        value = value.title()
    try:
        return eval(f"{datatype}({value})")
    except Exception as e:
        logger.error(
            f"cast_datatype() Error: (value={value}, datatype={datatype}). {e}"
        )
        if raise_errors:
            raise e
        return value


# Check value datatype
def validate_value_datatype(value, datatype):
    try:
        value = cast_datatype(value=value, datatype=datatype, raise_errors=True)
        return value
    except Exception as e:
        error = f"validate_value_datatype() Error: (value={value}, datatype={datatype}). {e}"
        logger.error(error)
        raise ValueError(error)


# Map fields
def map_fields(data: dict, mapping: dict, fields: list, sep="$$"):
    res = {}
    if not data:
        return res
    for field in fields:
        mapping_field = mapping.get(field, {})
        # key
        key = mapping_field.get("field")
        if not key:
            res[field] = None
            continue
        # value
        value = data.get(key)
        if not value and ("default" in mapping_field):
            value = mapping_field["default"]
        if "datatype" in mapping_field:
            value = cast_datatype(value=value, datatype=mapping_field["datatype"])
        # sep
        if sep in field:
            field_split = field.split(sep)
            if field_split[0] not in res:
                res[field_split[0]] = {}
            res[field_split[0]][field_split[1]] = value
            continue
        if sep in key:
            key_split = key.split(sep)
            value = data.get(key_split[0], {})
            if value:
                value = value.get(key_split[1])
            res[field] = value
            continue
        # res
        res[field] = value
    return res
