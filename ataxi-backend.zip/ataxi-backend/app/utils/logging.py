import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime

from ..settings import LOGGER


# Class 'LoggerUtils'
class LoggerUtils:
    def __init__(
        self,
        name="logger",
        path_file="main.log",
        is_weekly=False,
        is_daily=False,
        log_max_size_mb=10,
        log_backup_count=10,
    ):

        # Paths
        self.format_dt = "%Y%m"
        if is_weekly:
            self.format_dt = "%Y%m_%u"
        if is_daily:
            self.format_dt = "%Y%m%d"

        self.path_file = path_file.replace(
            ".log", "_{dt}.log".format(dt=datetime.now().strftime(self.format_dt))
        )

        # Formatter
        self.formatter = logging.Formatter(
            "%(asctime)s.%(msecs)03d: %(message)s", "%Y-%m-%d %H:%M:%S"
        )

        # File handler
        self.file_handler = RotatingFileHandler(
            filename=self.path_file,
            mode="a",
            maxBytes=(log_max_size_mb * 1024 * 1024),
            backupCount=log_backup_count,
            encoding=None,
            delay=False,
        )
        self.file_handler.setFormatter(self.formatter)

        # Console handler
        self.console_handler = logging.StreamHandler()
        self.console_handler.setFormatter(self.formatter)

        # Logger
        self.logger = logging.getLogger(name)
        self.logger.addHandler(self.file_handler)
        self.logger.addHandler(self.console_handler)
        self.logger.setLevel(logging.INFO)


logger = LoggerUtils(**LOGGER).logger
