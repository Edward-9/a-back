import json

from ..database import get_db
from ..utils import logger


# Get results from query to database
async def fetch_db_query(
    res_type: str = "rows",
    schema: str = "",
    func: str = "",
    q: str = "",
    q_params: str = "",
    q_s: str = "'",
    res_json=False,
    raise_errors=True,
    res_default=None,
    is_logging=True,
):
    if func:
        # run function
        res_type = "value"
        q = f"SELECT {schema}.{func}"
        if q_params:
            q_params = str(q_params).replace("None", "null")
            if q_s:
                q_params = q_params.replace("'", '"')
            q += f"({q_s}{q_params}{q_s})"
        else:
            q += "()"

    if res_json:
        res_default = {}

    db = await get_db()
    try:
        res = await db.fetch_query(query=q, res_type=res_type)
        if res_json and (type(res) is str) and res.startswith("{"):
            res = json.loads(res)
        if is_logging:
            logger.info(f"fetch_db_query() DB query: {q}")
    except Exception as e:
        res = res_default
        logger.error(f"fetch_db_query() Error: {q}, {db}, {e}")
        if raise_errors:
            raise e
    finally:
        pass

    return res
