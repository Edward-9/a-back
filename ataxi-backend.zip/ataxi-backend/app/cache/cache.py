from fastapi_cache import FastAPICache
from fastapi_cache.backends.redis import RedisBackend

from redis import asyncio as aioredis

from ..settings import REDIS_CACHE


def init_cache():
    redis = aioredis.from_url(
        url=REDIS_CACHE["host_url"], encoding="utf8", decode_responses=True
    )
    FastAPICache.init(RedisBackend(redis), prefix=REDIS_CACHE["prefix"])
